/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Shield, 
  ShieldCheck, 
  ShieldAlert, 
  Activity, 
  Terminal, 
  History, 
  Settings, 
  AlertTriangle,
  Cpu,
  Fingerprint,
  Plus,
  Mic,
  Radiation,
  Siren,
  Image as ImageIcon,
  FileText,
  Camera,
  X,
  Maximize2,
  Minimize2,
  ExternalLink,
  Target,
  Zap,
  Globe,
  Database,
  Lock,
  Layers,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { 
  analyzePrompt, 
  unifiedSecurityProcess,
  analyzeEmergencyVoicePrompt,
  generateEmergencyVoiceResponse,
  getEmergencyTTS
} from './services/geminiService';
import { FirewallLog, RiskLevel, SecurityAnalysis, VoiceStatus } from './types';

const THEME = {
  bg: '#020202',
  card: '#0A0A0A',
  accent: '#00F0FF',
  safe: '#00FF66',
  warning: '#FFCC00',
  danger: '#FF3333',
  border: 'rgba(0, 240, 255, 0.1)',
  glow: '0 0 20px rgba(0, 240, 255, 0.2)',
};

export default function App() {
  const [input, setInput] = useState('');
  const [logs, setLogs] = useState<FirewallLog[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string, type: 'error' | 'info' | 'success' } | null>(null);
  const [currentStep, setCurrentStep] = useState<'idle' | 'analyzing' | 'generating' | 'filtering'>('idle');
  const [rescueMode, setRescueMode] = useState(false);
  const [isCompact, setIsCompact] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<VoiceStatus>('idle');
  const [selectedMedia, setSelectedMedia] = useState<{ type: 'image' | 'file', url: string, name: string, mimeType: string, base64: string } | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [stats, setStats] = useState({ threatsBlocked: 0, totalChecks: 0, load: 0.04, learnedPatternsCount: 12 });
  const [activeTab, setActiveTab] = useState<'chat' | 'telemetry' | 'patterns'>('chat');
  const [learnedPatterns, setLearnedPatterns] = useState<string[]>([]);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    const fetchLogs = () => fetch('/api/firewall/logs').then(r => r.json()).then(setLogs).catch(err => console.error("Log fetch failed", err));
    const fetchStats = () => fetch('/api/firewall/stats').then(r => r.json()).then(setStats).catch(err => console.error("Stats fetch failed", err));
    const fetchPatterns = () => fetch('/api/firewall/patterns').then(r => r.json()).then(setLearnedPatterns).catch(err => console.error("Pattern fetch failed", err));

    fetchLogs();
    fetchStats();
    fetchPatterns();
    
    setStatusMessage({ text: "e Rakshak Neural Defense Online", type: 'info' });
    setTimeout(() => setStatusMessage(null), 4000);
    
    const statsInterval = setInterval(fetchStats, 1000);
    const logsInterval = setInterval(fetchLogs, 1000);
    const patternsInterval = setInterval(fetchPatterns, 5000);
    
    const params = new URLSearchParams(window.location.search);
    if (params.get('view') === 'overlay') {
      setIsCompact(true);
    }

    return () => {
      clearInterval(statsInterval);
      clearInterval(logsInterval);
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [logs, currentStep]);

  const handlePopOut = () => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('view', 'overlay');
      const win = window.open(url.toString(), 'eRakshakOverlay', 'width=450,height=750,menubar=no,status=no,location=no,toolbar=no');
      if (!win) {
        setStatusMessage({ text: "Popup blocked by browser. Please allow popups.", type: 'error' });
      } else {
        setStatusMessage({ text: "Secure overlay launched.", type: 'success' });
        setTimeout(() => setStatusMessage(null), 3000);
      }
    } catch (err) {
      setStatusMessage({ text: "Failed to launch overlay.", type: 'error' });
    }
  };

  const updateHUDMessage = (text: string, type: 'error' | 'info' | 'success', duration: number = 4000) => {
    setStatusMessage({ text, type });
    setTimeout(() => {
      setStatusMessage(prev => prev?.text === text ? null : prev);
    }, duration);
  };

  const processInteraction = async (text: string, media: any = null, isRescue: boolean = false) => {
    if (isProcessing) return;
    if (!text.trim() && !media) return;

    setIsProcessing(true);
    setStatusMessage(null);
    const logId = Math.random().toString(36).substr(2, 9);
    
    try {
      const mediaData = media ? { mimeType: media.mimeType, data: media.base64 } : undefined;
      setCurrentStep('analyzing');
      
      let analysis: SecurityAnalysis;
      let output: string;
      let isOutputSafe: boolean;

      if (isRescue) {
        analysis = await analyzeEmergencyVoicePrompt(text);
        const decisionResponse = await fetch('/api/firewall/decision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ analysis, input: text })
        });
        const decisionResult = await decisionResponse.json();
        if (!decisionResult.isSafe) {
          const logEntry = { id: logId, timestamp: Date.now(), input: text, analysis };
          logToBackend(logEntry);
          setLogs(prev => [logEntry, ...prev.slice(0, 49)]);
          speakResponse(`Threat detected: ${analysis.riskLevel}. Access denied.`);
          updateHUDMessage(`Blocked threat: ${analysis.riskLevel}`, 'error');
          return;
        }
        output = await generateEmergencyVoiceResponse(text);
        isOutputSafe = true;
      } else {
        const unified = await unifiedSecurityProcess(text, mediaData, learnedPatterns);
        analysis = unified.analysis;
        output = unified.output;
        isOutputSafe = unified.isOutputSafe;

        const decisionResponse = await fetch('/api/firewall/decision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ analysis, input: text })
        });
        
        if (!decisionResponse.ok) throw new Error("Decision service unreachable");
        
        const decisionResult = await decisionResponse.json();
        setStats(decisionResult.stats);

        if (!decisionResult.isSafe) {
          const logEntry = { id: logId, timestamp: Date.now(), input: text, analysis };
          logToBackend(logEntry);
          setLogs(prev => [logEntry, ...prev.slice(0, 49)]);
          speakResponse(`Threat detected: ${analysis.riskLevel}. Access denied.`);
          updateHUDMessage(`Blocked threat: ${analysis.riskLevel}`, 'error');
          return;
        }
      }

      const finalLogEntry = {
        id: logId,
        timestamp: Date.now(),
        input: text,
        analysis,
        output: output,
        outputFiltered: !isOutputSafe,
        media: media ? { type: media.type, name: media.name, url: media.url } : undefined
      };

      logToBackend(finalLogEntry);
      setLogs(prev => [finalLogEntry, ...prev.slice(0, 49)]);

      if (isRescue) speakResponse(output, true);
      setInput('');
      setSelectedMedia(null);
    } catch (e: any) {
      console.error(e);
      updateHUDMessage(`System Error: ${e.message || "Failed to process request"}`, 'error');
    } finally {
      setIsProcessing(false);
      setCurrentStep('idle');
    }
  };

  const logToBackend = async (data: any) => {
    await fetch('/api/firewall/logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    readFile(file);
  };

  const readFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = (e.target?.result as string).split(',')[1];
      const type = file.type.startsWith('image/') ? 'image' : 'file';
      setSelectedMedia({
        type,
        url: URL.createObjectURL(file),
        name: file.name,
        mimeType: file.type,
        base64
      });
    };
    reader.readAsDataURL(file);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
        };
      }
      setIsCameraOpen(true);
    } catch (err) {
      console.error("Camera access denied:", err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraOpen(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(videoRef.current, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg');
      const base64 = dataUrl.split(',')[1];
      
      setSelectedMedia({
        type: 'image',
        url: dataUrl,
        name: `capture_${Date.now()}.jpg`,
        mimeType: 'image/jpeg',
        base64
      });
      stopCamera();
    }
  };

  const toggleVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return alert("Browser not supported");
    const rec = new SpeechRecognition();
    rec.onstart = () => setVoiceStatus('listening');
    rec.onresult = (e: any) => processInteraction(e.results[0][0].transcript, null, rescueMode);
    rec.onend = () => setVoiceStatus('idle');
    rec.start();
  };

  const speakResponse = async (text: string, forceHighQuality: boolean = false) => {
    setVoiceStatus('speaking');
    if (forceHighQuality || rescueMode) {
      try {
        const audioData = await getEmergencyTTS(text);
        if (!audioData) throw new Error();
        if (!audioContextRef.current) audioContextRef.current = new AudioContext();
        const buffer = await audioContextRef.current.decodeAudioData(Uint8Array.from(atob(audioData), c => c.charCodeAt(0)).buffer);
        const src = audioContextRef.current.createBufferSource();
        src.buffer = buffer;
        src.connect(audioContextRef.current.destination);
        src.onended = () => setVoiceStatus('idle');
        src.start();
        return;
      } catch (e) {
        console.error("High quality TTS failed, falling back", e);
      }
    }
    
    const u = new SpeechSynthesisUtterance(text);
    u.onend = () => setVoiceStatus('idle');
    speechSynthesis.speak(u);
  };

  const getRiskColor = (l: RiskLevel) => {
    if (l === RiskLevel.LOW) return THEME.safe;
    if (l === RiskLevel.MEDIUM) return THEME.warning;
    return THEME.danger;
  };

  const isOverlayMode = new URLSearchParams(window.location.search).get('view') === 'overlay';

  return (
    <div className={`flex h-screen flex-col font-mono text-[13px] text-white selection:bg-cyan-500/30 ${rescueMode ? 'bg-red-950/20' : 'bg-[#020202]'}`}>
      {/* HUD Header */}
      {!isOverlayMode && (
        <header className="z-50 flex shrink-0 items-center justify-between border-b border-cyan-500/10 bg-black/60 px-6 py-3 backdrop-blur-xl">
          <div className="flex items-center gap-4">
            <div className={`flex size-10 items-center justify-center rounded-sm border transition-all ${rescueMode ? 'border-red-500 shadow-[0_0_15px_red]' : 'border-cyan-500 shadow-[0_0_15px_#00F0FF33]'}`}>
              {rescueMode ? <Siren className="size-6 text-red-500" /> : <Globe className="size-6 text-cyan-400" />}
            </div>
            <div>
              <h1 className="text-lg font-black tracking-widest text-cyan-400">e_RAKSHAK v4.2</h1>
              <div className="flex items-center gap-3 text-[9px] opacity-60">
                <span className="flex items-center gap-1 uppercase"><Activity className="size-3" /> System_Online</span>
                <span className="text-cyan-500/30">|</span>
                <span className="text-rose-400">Threats: {stats.threatsBlocked}</span>
                <span className="text-cyan-500/30">|</span>
                <span className="text-emerald-400">Load: {stats.load}ms</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => setIsCompact(!isCompact)} className="flex size-9 items-center justify-center rounded-sm bg-white/5 hover:bg-white/10">{isCompact ? <Maximize2 size={16}/> : <Minimize2 size={16}/>}</button>
            <button onClick={handlePopOut} className="flex size-9 items-center justify-center rounded-sm bg-white/5 hover:bg-white/10"><ExternalLink size={16}/></button>
            <button onClick={() => setRescueMode(!rescueMode)} className={`px-4 py-2 font-black transition-all ${rescueMode ? 'bg-red-600 shadow-[0_0_20px_red]' : 'bg-white/5 text-slate-400'}`}>
              {rescueMode ? 'OVERRIDE_ACTIVE' : 'EMERGENCY_PROT'}
            </button>
          </div>
        </header>
      )}

      <main className={`mx-auto flex w-full flex-1 gap-4 overflow-hidden transition-all ${isOverlayMode ? 'p-0 h-full w-full' : 'p-4 max-w-[1600px]'} ${isCompact && !isOverlayMode ? 'fixed bottom-4 right-4 h-[600px] w-[400px] flex-col rounded-xl border border-cyan-500/20 bg-black/90 shadow-2xl backdrop-blur-2xl' : ''}`}>
        
        {/* Main Interface */}
        <div className={`flex h-full flex-1 flex-col overflow-hidden border-white/5 bg-[#080808] ${isOverlayMode ? 'border-none' : 'rounded-sm border'}`}>
          {/* Bento Tabs (Non-compact only) */}
          {!isCompact && (
            <div className="flex border-b border-white/5">
              {[ { id: 'chat', icon: Terminal, label: 'COMMAND_LINE' }, { id: 'telemetry', icon: Layers, label: 'NEURAL_MAP' }, { id: 'patterns', icon: Target, label: 'ADAPTIVE_ML' }].map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`flex items-center gap-2 px-6 py-3 text-[10px] font-bold tracking-widest transition-all ${activeTab === tab.id ? 'bg-cyan-500/10 text-cyan-400' : 'opacity-40 hover:opacity-100'}`}>
                  <tab.icon size={14} /> {tab.label}
                </button>
              ))}
            </div>
          )}

          <div className="flex flex-1 overflow-hidden">
            {/* In-view Telemetry (Left Sidebar - Non-compact only) */}
            {!isCompact && (
              <aside className="w-80 border-r border-white/5 bg-black/40 p-4 space-y-6">
                <div className="space-y-4">
                  <h3 className="text-[10px] font-black text-cyan-400 uppercase tracking-tighter">Realtime_Neural_Flow</h3>
                  <div className="h-40 rounded-sm border border-white/5 bg-black/60 relative overflow-hidden">
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
                    <motion.div animate={{ y: [0, 140, 0] }} transition={{ repeat: Infinity, duration: 4, ease: "linear" }} className="h-0.5 w-full bg-cyan-500/40 shadow-[0_0_10px_cyan]" />
                    <div className="p-4 flex flex-col gap-2">
                      <div className="flex justify-between text-[9px]"><span className="opacity-40 uppercase">Entropy</span><span className="text-emerald-400">0.022</span></div>
                      <div className="flex justify-between text-[9px]"><span className="opacity-40 uppercase">Latency</span><span className="text-cyan-400">{stats.load}ms</span></div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-[10px] font-black text-cyan-400 uppercase font-mono">System_Stats</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-3 bg-white/5 border border-white/5 text-center transition-all hover:border-cyan-500/20">
                      <span className="block text-[8px] opacity-40 uppercase">Blocked</span>
                      <span className="text-rose-500 font-black">{stats.threatsBlocked}</span>
                    </div>
                    <div className="p-3 bg-white/5 border border-white/5 text-center transition-all hover:border-cyan-500/20">
                      <span className="block text-[8px] opacity-40 uppercase">Checks</span>
                      <span className="text-cyan-400 font-black">{stats.totalChecks}</span>
                    </div>
                  </div>
                </div>
              </aside>
            )}

            {/* Thread Area (Right Side) */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-8 scroll-smooth scrollbar-thin scrollbar-thumb-white/10">
              {logs.length === 0 ? (
                 <div className="flex h-full flex-col items-center justify-center text-center opacity-20">
                    <Fingerprint size={64} className="mb-4 text-cyan-500" />
                    <p className="tracking-widest">INITIALIZING_SECURE_HANDSHAKE...</p>
                 </div>
              ) : (
                logs.map(log => (
                  <motion.div 
                    key={log.id} 
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-4"
                  >
                    {/* User Entry */}
                    <div className="flex justify-end">
                      <div className="max-w-[80%] space-y-1">
                        <span className="block text-[9px] opacity-40 text-right">SOURCE: USER_NODE</span>
                        <div className="rounded-lg border border-white/5 bg-white/5 p-4 text-slate-300">
                          {log.media && (
                            <div className="mb-3 overflow-hidden rounded-lg border border-white/10">
                               {log.media.type === 'image' ? (
                                 <img src={log.media.url} alt="User upload" className="max-h-64 w-full object-contain bg-black/40" />
                               ) : (
                                 <div className="flex items-center gap-3 bg-white/5 p-4">
                                   <FileText className="size-6 text-cyan-400" />
                                   <span className="text-xs truncate">{log.media.name}</span>
                                 </div>
                               )}
                            </div>
                          )}
                          {log.input}
                        </div>
                      </div>
                    </div>

                    {/* System Entry */}
                    <div className="flex justify-start">
                      <div className="max-w-[90%] space-y-3">
                        <div className={`p-2 rounded-sm border flex items-center gap-3 ${log.analysis.isSafe ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
                           {log.analysis.isSafe ? <ShieldCheck size={14} className="text-emerald-400"/> : <AlertTriangle size={14} className="text-red-500"/>}
                           <span className={`text-[9px] font-black uppercase ${log.analysis.isSafe ? 'text-emerald-400' : 'text-red-500'}`}>
                             {log.analysis.isSafe ? 'THREAT_SCAN_CLEAR' : 'MALICIOUS_ACTIVITY_DETECTED'}
                           </span>
                           <span className="ml-auto text-[8px] opacity-40">RISK: {log.analysis.riskLevel}</span>
                        </div>
                        <div className={`rounded-lg border p-4 ${log.analysis.isSafe ? 'border-cyan-500/20 bg-cyan-500/5' : 'border-red-500/20 bg-red-500/5 text-red-300'}`}>
                          {log.analysis.isSafe ? (
                            <div className="prose prose-invert prose-sm max-w-none"><Markdown>{log.output}</Markdown></div>
                          ) : (
                            <p className="text-xs italic">"System Intercepted: {log.analysis.explanation}"</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>

          {/* Commander Input */}
          <div className="p-6 border-t border-white/5">
             <div className="mx-auto max-w-4xl space-y-4">
                {/* Status Message Overlay */}
                <AnimatePresence>
                  {statusMessage && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={`flex items-center gap-2 rounded-sm px-4 py-2 text-[10px] font-black uppercase tracking-widest border border-white/10 ${
                        statusMessage.type === 'error' ? 'bg-red-500/20 text-red-500' : 
                        statusMessage.type === 'success' ? 'bg-emerald-500/20 text-emerald-400' : 
                        'bg-cyan-500/10 text-cyan-400'
                      }`}
                    >
                      {statusMessage.type === 'error' ? <AlertTriangle size={14}/> : <ShieldCheck size={14}/>}
                      {statusMessage.text}
                      <button onClick={() => setStatusMessage(null)} className="ml-auto opacity-40 hover:opacity-100"><X size={12}/></button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Media Preview */}
                <AnimatePresence>
                  {selectedMedia && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0 }}
                      className="flex w-fit items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-2 pr-1"
                    >
                      <div className="size-10 overflow-hidden rounded-lg bg-black/40">
                         {selectedMedia.type === 'image' ? (
                           <img src={selectedMedia.url} className="h-full w-full object-cover" />
                         ) : (
                           <div className="flex h-full w-full items-center justify-center"><FileText className="size-4" /></div>
                         )}
                      </div>
                      <span className="max-w-[120px] truncate text-[10px] font-medium opacity-60">{selectedMedia.name}</span>
                      <button onClick={() => setSelectedMedia(null)} className="flex size-8 items-center justify-center rounded-lg hover:bg-white/10"><X className="size-3 text-red-500" /></button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Camera Overlay */}
                <AnimatePresence>
                  {isCameraOpen && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="absolute inset-x-0 bottom-full mb-4 mx-auto max-w-lg overflow-hidden rounded-2xl border border-cyan-500/50 shadow-2xl z-50 bg-black"
                    >
                      <video ref={videoRef} autoPlay playsInline className="aspect-video w-full object-cover" />
                      <div className="absolute inset-0 flex items-end justify-center p-6 bg-gradient-to-t from-black/80 to-transparent">
                         <div className="flex gap-4">
                           <button onClick={capturePhoto} className="flex size-14 items-center justify-center rounded-full bg-cyan-500 text-black shadow-[0_0_20px_cyan] active:scale-95"><Camera className="size-7" /></button>
                           <button onClick={stopCamera} className="flex size-14 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-md active:scale-95"><X className="size-7" /></button>
                         </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="relative flex items-center gap-3">
                    <AnimatePresence>
                      {isProcessing && (
                        <motion.div initial={{ width: 0 }} animate={{ width: 'auto' }} className="flex items-center gap-2 rounded-sm bg-cyan-500/10 px-3 py-2 border border-cyan-500/20">
                          <Zap size={14} className="text-cyan-400 animate-pulse" />
                          <span className="text-[10px] font-bold text-cyan-400 truncate">{currentStep.toUpperCase()}...</span>
                        </motion.div>
                      )}
                    </AnimatePresence>
                    <div className={`flex flex-1 items-center rounded-sm border p-2 px-4 transition-all ${isProcessing ? 'border-cyan-500/20 bg-cyan-500/5 cursor-not-allowed opacity-60' : 'border-white/10 bg-white/5 focus-within:border-cyan-500/50'}`}>
                      <input 
                        value={input}
                        disabled={isProcessing}
                        onChange={e => setInput(e.target.value)}
                        placeholder={isProcessing ? "PROCESSING_REQUEST..." : rescueMode ? "AWAITING_EMERGENCY_VOICE_COMMAND..." : "EXECUTE_SECURE_COMMAND_..."}
                        onKeyDown={e => e.key === 'Enter' && processInteraction(input, selectedMedia)}
                        className="flex-1 bg-transparent outline-none py-2 disabled:cursor-not-allowed"
                      />
                      <div className="flex items-center gap-2">
                        {!isProcessing && (
                          <>
                            <button onClick={() => fileInputRef.current?.click()} className="p-2 text-slate-500 hover:text-white transition-colors" title="Attach Files"><ImageIcon size={18} /></button>
                            <button onClick={startCamera} className="p-2 text-slate-500 hover:text-white transition-colors" title="Camera Scan"><Camera size={18} /></button>
                            <button onClick={toggleVoice} className={`p-2 transition-all ${voiceStatus === 'listening' ? 'text-red-500' : 'text-slate-500 hover:text-white'}`}><Mic size={18} /></button>
                          </>
                        )}
                        <button 
                          disabled={isProcessing || (!input.trim() && !selectedMedia)}
                          onClick={() => processInteraction(input, selectedMedia)} 
                          className={`px-4 py-2 font-black transition-all ${
                            isProcessing || (!input.trim() && !selectedMedia) 
                              ? 'bg-white/5 text-white/20 cursor-not-allowed' 
                              : 'bg-cyan-500 text-black hover:bg-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.4)]'
                          }`}
                        >
                          {isProcessing ? 'BUSY' : 'SUBMIT'}
                        </button>
                      </div>
                    </div>
                </div>

                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*,application/pdf,text/*" />
             </div>
          </div>
        </div>

        {/* Floating Metrics (Compact Only) */}
        {isCompact && (
          <div className="absolute top-2 left-2 flex gap-4 p-2 bg-black/80 rounded-lg border border-white/10">
            <div className="flex flex-col"><span className="text-[8px] opacity-40">THREATS</span><span className="text-rose-500 font-black">{stats.threatsBlocked}</span></div>
            <div className="flex flex-col"><span className="text-[8px] opacity-40">LATENCY</span><span className="text-cyan-400 font-black">{stats.load}ms</span></div>
          </div>
        )}
      </main>
    </div>
  );
}
