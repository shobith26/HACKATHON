export enum RiskLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export interface SecurityAnalysis {
  isSafe: boolean;
  riskLevel: RiskLevel;
  threatsIdentified: string[];
  explanation: string;
}

export interface FirewallLog {
  id: string;
  timestamp: number;
  input: string;
  analysis: SecurityAnalysis;
  output?: string;
  outputFiltered?: boolean;
  media?: {
    type: 'image' | 'file';
    name: string;
    mimeType?: string;
    url?: string;
  };
}

export type VoiceStatus = 'idle' | 'listening' | 'processing' | 'speaking';
