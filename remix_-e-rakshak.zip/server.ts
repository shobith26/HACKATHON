import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // In-memory store for demo purposes
  const logs: any[] = [
    {
      id: 'welcome',
      timestamp: Date.now(),
      input: 'SYSTEM_INITIALIZATION',
      analysis: { isSafe: true, riskLevel: 'LOW', explanation: 'System boot successful.' },
      output: 'Hi, I am e Rakshak. System online and ready for neural defense.',
      media: null
    }
  ];
  const stats = {
    threatsBlocked: 0,
    totalChecks: 0,
    load: 0.04,
    learnedPatternsCount: 12
  };
  const learnedPatterns = ["Polymorphic_Payload_V4", "System_Prompt_Injection", "Stealth_Exfiltration_Ref"];

  // API Routes
  app.get("/api/firewall/logs", (req, res) => {
    res.json(logs);
  });

  app.post("/api/firewall/logs", (req, res) => {
    const log = req.body;
    logs.push(log);
    if (logs.length > 50) logs.shift();
    res.status(201).json({ success: true });
  });

  app.get("/api/firewall/stats", (req, res) => {
    // Simulate slight fluctuation
    stats.load = parseFloat((0.03 + Math.random() * 0.05).toFixed(2));
    res.json(stats);
  });

  app.get("/api/firewall/patterns", (req, res) => {
    res.json(learnedPatterns);
  });

  app.post("/api/firewall/decision", (req, res) => {
    const { analysis, input } = req.body;
    stats.totalChecks++;
    
    // Heuristic backend check
    let isSafe = analysis.isSafe;
    if (input.toLowerCase().includes("rm -rf") || input.toLowerCase().includes("drop table")) {
      isSafe = false;
    }

    if (!isSafe) {
      stats.threatsBlocked++;
      // Add fake patterns if we "learned" something
      if (Math.random() > 0.8) {
        stats.learnedPatternsCount++;
      }
    }

    res.json({ isSafe, stats });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
